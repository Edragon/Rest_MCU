/*
*========================================================================================================
*
* File                : TEST_led_T0.c
* Hardware Environment:	OpenPIC16F877A && 8LED &&  5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>

__CONFIG(0x3B31);
#define uchar unsigned char
#define uint unsigned int

uchar count;
void main()
{
TRISB=0;
PORTB=0;
OPTION_REG=0x04;
INTCON=0xA0;
TMR0=0;
while(1)
{
  if(count==50)
  {
   count=0;
   PORTB=~PORTB;
  }
}
}
void interrupt timer0()
{

T0IF=0;
count++;
}
