/********************************************************************************************************
*********************************************************************************************************
*
* File                : SPI_SD_Card.c
* Hardware Environment:	OpenPIC16F877A && SD && 8LED && 3v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>               
 __CONFIG(0xFF32);
#define  cs   RA5             


void  spi_init();          
void  spi_low();            
void  spi_high();             
unsigned char sd_reset();     
unsigned char SD_SendCommand(unsigned char cmd,unsigned long arg); 
unsigned char SPI_WriteByte(unsigned char val);                    
unsigned char SPI_ReadByte(void);                                 
unsigned char SD_WriteSingleBlock(unsigned long sector);           
unsigned char SD_ReadSingleBlock(unsigned long sector);           
void display(unsigned char temp);                                 
void  delay();                                                     
void  delay_ms(unsigned int x);

void main()
{
     unsigned char loop,res;
     delay();
     delay();
     delay();
     loop=1;

     cs=1;
     while(loop)
     {
        spi_init();                    
        res= sd_reset();             
       
 
       PORTB=0X0F; delay_ms(50);         

        SD_WriteSingleBlock(1);       
            if(res) break;
        
	PORTB=0XF0; delay_ms(50);

		SD_ReadSingleBlock(1);        
           if(res) break;

PORTB=0X0F; delay_ms(50);                 

        loop=0;
        
         while(1);
     }
   
     while(1);
}    
void display(unsigned char temp) 
{
     TRISB=0;
	 PORTB=temp;
     delay_ms(10);
}

void spi_init()
{
  TRISC=0xd0;                     
  TRISB=0X00; PORTB=0XFF;                     
  TRISA=0X00;                     
  ADCON1=0X07;                      
  PORTA=0XFF;


  SSPCON=0x31;                      
  SSPSTAT=0x80;                    

}


void spi_low()
{
  SSPCON=0x31;                    
}


void spi_high()
{

    SSPCON=0X30;
}

///////////////////////////////////////////////
//
unsigned char SPI_WriteByte(unsigned char val)
{
	SSPBUF = val;               
	while(!SSPIF);             
    SSPIF=0;                     
	return SSPBUF;              
}


unsigned char SPI_ReadByte(void)
{
	SSPBUF = 0xff;              
	while(!SSPIF);              
    SSPIF=0;                     
	return SSPBUF;               
}


unsigned char SD_SendCommand(unsigned char cmd,unsigned long arg)
{
	unsigned char r1;
	unsigned char retry1=0;      
	
	cs=0;                        
	
	SPI_WriteByte(cmd | 0x40);   
	SPI_WriteByte(arg>>24);      
	SPI_WriteByte(arg>>16);     
	SPI_WriteByte(arg>>8);      
	SPI_WriteByte(arg);         
	SPI_WriteByte(0x95);        
	
	while((r1 = SPI_WriteByte(0xff)) == 0xff)
		if(retry1++ > 200) break;				
     
	cs=1;                        

	return r1;                  
}

unsigned char sd_reset()
{
 unsigned char i,tmp;
 unsigned char retry;           
 unsigned char r1=0;              
 retry=0;
 delay();
 delay();
 spi_low();                     
 do
	{
        for(i=0;i<100;i++) SPI_WriteByte(0xff);
      
		r1 = SD_SendCommand(0,0);	
		retry++;
		if(retry>20) return 1;   
	} while(r1 != 0x01);	     

	retry = 0;                    
    cs=0;
 	do
	{
        for(i=0;i<100;i++) SPI_WriteByte(0xff);

		r1 = SD_SendCommand(1, 0);        
		retry++;
		if(retry>254) return 1;           
       } while(r1);		
	spi_high();                            

    for(i=0;i<100;i++) SPI_WriteByte(0xff);

	r1 = SD_SendCommand(59, 0);           	
   if (r1) return 1;              

	for(i=0;i<100;i++) SPI_WriteByte(0xff);

    r1 = SD_SendCommand(16, 512);         
    if(r1!=0) return 1;                   
	return 0;                           	
}


unsigned char SD_WriteSingleBlock(unsigned long sector)
{
	unsigned char r1;
	unsigned int i;
    unsigned char retry=0;
    spi_low();
	do
	{
        for(i=0;i<100;i++) SPI_WriteByte(0xff);

		r1 = SD_SendCommand(24, sector<<9);
		retry++;
		if(retry>10) return 1;            
	} while(r1 != 0x00);	

	cs=0;
	
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);
	SPI_WriteByte(0xff);                  

	SPI_WriteByte(0xfe);                  
	
	for(i=0; i<512; i++)                  
	{
        if(i<255) SPI_WriteByte(i);       
		else SPI_WriteByte(512-i);     
         
	}
	
	SPI_WriteByte(0x95);
	SPI_WriteByte(0x95);                 

	r1 = SPI_WriteByte(0xff);            
    if(retry++ >10) return 1;           
    while(!((r1&0x0f)==5));              
    while(!(SPI_WriteByte(0xff)));     
   
	return 0;
}
      
////////////////////////////////////////////////
//��SD��һ������
unsigned char SD_ReadSingleBlock(unsigned long sector)
{
	unsigned char r1,temp;
	unsigned int i,j;
	unsigned char retry=0;

	do
	{
		r1 = SD_SendCommand(17, sector<<9);
		retry++;
		if(retry>10) return 1;           
	} while(r1 != 0x00);	
	cs=0;
	while(SPI_WriteByte(0xff)!= 0xfe)      
     {
       if(retry++ >100) return 1;         
     }
	for(i=0; i<512; i++)                   
	{
		temp = SPI_WriteByte(0xff);       
       
        display(temp);                     
         
	}

	SPI_WriteByte(0xff);                  
	SPI_WriteByte(0xff);
	
	cs=1;

	return 0;
}


void  delay()              
    {
     int i;                
     for(i=0x100;i--;);     
    }

    
void  delay_ms(unsigned int x)              
    {
  unsigned   int i,j;                
     for(i=0;i<x;i++)for(j=0;j<100;j++);     
    }