/*
*========================================================================================================
*
* File                : Timer1_LED.c
* Hardware Environment:	OpenPIC16F877A && 8LED &&  5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/

#include <pic.h>
 __CONFIG(0x1832); 

void main(void)
{ 
  T1CKPS0=0;         
  T1CKPS1=0;               
  TMR1CS=0;               
  
  TMR1L=(65536-12500)%256;  
  TMR1H=(65536-12500)/256; 
  
  GIE=1;     
  PEIE=1;    
  TMR1IE=1;  
  
  TMR1ON=1;  
  
  TRISB=0;      
  PORTB=0;  
  
   
  while(1)
  {
    
  } 
}

void interrupt isr(void)
{
  if(TMR1IE&&TMR1IF)      
  {
    TMR1L=(65536-12500)%256;
    TMR1H=(65536-12500)/256;
    
    TMR1IF=0;              
    PORTB=PORTB+1;        
  } 
} 