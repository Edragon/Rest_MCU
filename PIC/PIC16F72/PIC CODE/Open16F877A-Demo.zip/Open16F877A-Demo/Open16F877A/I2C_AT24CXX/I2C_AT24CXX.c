/*
*========================================================================================================
*
* File                :I2C_AT24CXX.c
* Hardware Environment:	OpenPIC16F877A && at24cxx && led && 5v voltage && 4M/8M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>
volatile       bit	STAT_RW		@ (unsigned)&SSPSTAT*8+2;
volatile       bit	STAT_BF		@ (unsigned)&SSPSTAT*8+0;
 #define address  0xa
 #define nop() asm("asm")
 __CONFIG(0xFF32);        

const char ee_data_write[]={0x6,0x5,0x4,0x3,0x2,0x1};
 unsigned char ee_date[6];

void write();
void read();
void wrtacktest();
void i2c_idle();
void delay();
void display();
void init();

void main()
 {
   init();
   while(1)
     {
      
           write();
      
        
           read();
           while(1)
             {
             display();
             }
         }
      
  }

void init()
  {
   STATUS=0X0;
 
   TRISC=0Xff;
  
   TRISB=0X0;
  
   SSPADD=0X9;
   SSPSTAT=0X80;
   SSPCON=0X38;
  }
  
void write()
  {
    int i;
    i2c_idle();
    SEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=0XA0;
    wrtacktest();
    while(STAT_BF);
    SSPBUF=address;
    wrtacktest();
    while(STAT_BF);
 
    for(i=0;i<6;i++)
      {
         SSPBUF=ee_data_write[i];
         wrtacktest();
      }
    PEN=1;
    nop();
    SSPIF=0;
    delay();
    delay();
    PORTD=0XA4;
    PORTA=0X3E;
 }

void read()
 {
    static volatile unsigned int i;
    i2c_idle();
    SSPIF=0;
    SEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=0XA0;
    wrtacktest();
    SSPBUF=address;
    wrtacktest();
    
    i2c_idle();
    SSPIF=0;
    RSEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=0XA1;
    wrtacktest();
   
    for(i=0;i<6;i++)
       {
          RCEN=1;
          while(!SSPIF);
          ee_date[i]=SSPBUF;
          while(!SSPIF);
          SSPIF=0;
          if(i>=5) 
              {
                ACKDT=1;
              }
          else     
              {
                ACKDT=0;
              }
          ACKEN=1;
          while(!SSPIF);
          SSPIF=0;
       }
   
    PEN=1;
    while(!SSPIF);
    SSPIF=0;
 }
     
void wrtacktest()
 {
   while(!SSPIF);
   SSPIF=0;
 }

void i2c_idle()
 {
   while(STAT_RW);
   ZERO=0;
   while(ZERO)
     {
       SSPCON2&0x1f;
     }
 }
    
void display()
   { 
     int i;
    for(i=0;i<6;i++)
    {
PORTB=ee_date[i];delay();
}
     

   }

void delay()
 {
    int i,J;
    for(i=0;i<500;i++)
        for(J=0;J<100;J++);
 }
 
