/*
*========================================================================================================
*
* File                : I2C_PCF8591.c
* Hardware Environment:	OpenPIC16F877A && PCF8591 && 8LED && 5v voltage && 4M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include  <pic.h>
 __CONFIG(0xff32); 
typedef unsigned short u16;
typedef unsigned char  u8;
volatile       bit	STAT_RW		@ (unsigned)&SSPSTAT*8+2;
volatile       bit	STAT_BF		@ (unsigned)&SSPSTAT*8+0;

#define CHNL0 	0		//Using Channel0
#define MODE0 	0x00	//Channel0 = AIN0;
#define WR_DADR		0x90	//write device-address 
#define RD_DADR		0x91	//read device-address
#define nop() asm("asm")  

#define DAouputEn	0x40	//0x50 or 0x60 or 0x70 is also ok!

void delay_ms( unsigned int x)
{
    unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
void delay_1ms()
 {
    int i;
    for(i=0;i<100;i++)
       {;}
 }
void twi_init()
  {
   STATUS=0X0; 
   TRISC=0XF0;  
   SSPADD=0X9;
   SSPSTAT=0X80;
   SSPCON=0X38;
  }
void i2c_idle()
 {
   while(STAT_RW);
   ZERO=0;
   while(ZERO)
     {
       SSPCON2&0x1f;
     }
 }


void wrtacktest()
 {
   while(!SSPIF);
   SSPIF=0;
 }


void I2C_Write(u16 wrDAdr,u8 wordAdr,u8 dat)
{
    i2c_idle();
    SEN=1;
    while(!SSPIF);
    SSPIF=0;

    SSPBUF=((u8)(wrDAdr>>8));
    wrtacktest();
    while(STAT_BF);

    SSPBUF=(u8)wrDAdr;
    wrtacktest();
  while(STAT_BF);
 
   SSPBUF=wordAdr;
     wrtacktest();  
     while(STAT_BF);

         SSPBUF=dat;
         wrtacktest();
     
    PEN=1;   
     nop();	
    SSPIF=0;
 
}

u8 I2C_Read(u16 wrDAdr,u8 wordAdr,
			  u8 rdDAdr) 
  {  u8  receive_da; 
    i2c_idle();
    SSPIF=0;
    SEN=1; 
    while(!SSPIF);PORTB =1;
    SSPIF=0;

   SSPBUF=((u8)(wrDAdr>>8));
    wrtacktest();
   ///// while(STAT_BF);

    SSPBUF=(u8)wrDAdr;
    wrtacktest();
  ////  while(STAT_BF);
 
    SSPBUF=wordAdr;      
    wrtacktest();  
   ///// while(STAT_BF);
    
    i2c_idle();          
    SSPIF=0;
    RSEN=1;
    while(!SSPIF);
    SSPIF=0;

    SSPBUF=rdDAdr;    
    wrtacktest();
   
   
          RCEN=1;
          while(!SSPIF);
          receive_da =SSPBUF;
          while(!SSPIF);
          SSPIF=0;

                ACKDT=1;
            
          ACKEN=1;
          while(!SSPIF);
          SSPIF=0;
        
   
    PEN=1;
    
    SSPIF=0;
	return	receive_da ; 
 }


 main(void)
{
	u8 DAval=0;
	TRISB=0;PORTB =0;
	twi_init();	     	
	while(1)
	{PORTB =I2C_Read(WR_DADR,MODE0|CHNL0,RD_DADR);
		I2C_Write(WR_DADR,DAouputEn,DAval++);
       
        
		delay_ms(100);
	}
}
