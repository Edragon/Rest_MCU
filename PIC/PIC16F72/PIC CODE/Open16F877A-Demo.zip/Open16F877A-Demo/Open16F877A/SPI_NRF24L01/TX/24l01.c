/*
*========================================================================================================
*
* File                : 24l01.c
* Hardware Environment:	
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/

#include <pic.h>
#include "24L01.h"

#define TX_ADR_WIDTH   	5  
#define TX_PLOAD_WIDTH 	32  
#define u8				unsigned char
#define	RX_DR			0x40
#define	TX_DS			0x20
#define	MAX_RT			0x10
#define u8				unsigned char
#define u16				unsigned int
u8 TX_ADDRESS[TX_ADR_WIDTH] = {0xb2,0xb2,0xb3,0xb4,0x01};  
u8 RX_BUF[TX_PLOAD_WIDTH];
u8 TX_BUF[TX_PLOAD_WIDTH]={
0x01,0x02,0x03,0x4,0x05,0x06,0x07,0x08,
0x09,0x10,0x11,0x12,0x13,0x14,0x15,0x16,
0x17,0x18,0x19,0x20,0x21,0x22,0x23,0x24,
0x25,0x26,0x27,0x28,0x29,0x30,0x31,0x32};



void spi_init()
{
     ADCON1=0X07;
     TRISA=0X10;
     TRISB=0X0;
     TRISC=0X10;
    
     SSPSTAT=0XC0;
     SSPCON=0X20;
    INTCON=0X00;
     PIR1=0X00;
}
 void SPI_Send_byte(u8 data)
{
  SSPBUF=data;
     while(!SSPIF);
     SSPIF=0;
}

static u8 SPI_Receive_byte(u8 data)
{
u8  temp;
 	     SSPBUF=data;
     while(!SSPIF);
     SSPIF=0;
     temp=SSPBUF;
	return temp;
}

static void delay1us(u16 t)
{
	while(--t);
} 


u8 SPI_RW_Reg(u8 reg,u8 value)
{
	u8 status;
	CSN(0);
	status=SPI_Receive_byte(reg);   //select register  and write value to it
	SPI_Send_byte(value);   
	CSN(1);
	return(status); 
}

u8 SPI_Read_Reg(u8 reg)
{
	u8 status;
	CSN(0);
	SPI_Send_byte(reg);
	status=SPI_Receive_byte(0);   //select register  and write value to it
	CSN(1);
	return(status);
}

u8 SPI_Read_Buf(u8 reg,u8 *pBuf,u8 bytes)
{
	u8 status,byte_ctr;
	CSN(0);
	status=SPI_Receive_byte(reg);       
	for(byte_ctr=0;byte_ctr<bytes;byte_ctr++)
		pBuf[byte_ctr]=SPI_Receive_byte(0);
	CSN(1);
	return(status);
}


u8 SPI_Write_Buf(u8 reg,u8 *pBuf,u8 bytes)
{
	u8 status,byte_ctr;
	CSN(0);
	status=SPI_Receive_byte(reg); 
	delay1us(1);
	for(byte_ctr=0;byte_ctr<bytes;byte_ctr++)
		SPI_Send_byte(*pBuf++);
	CSN(1);
	return(status);
}


u8 nRF24L01_RxPacket(u8* rx_buf)
{
    u8 status,revale=0;
	CE(0);
	delay1us(10);
	status=SPI_Receive_byte(STATUS);	
//	CE(0);
//	status=0x40;
////
	if(status & RX_DR)			
	{
//		CE(1);
		SPI_Read_Buf(RD_RX_PLOAD,rx_buf,TX_PLOAD_WIDTH);// read receive payload from RX_FIFO buffer
//		CE(0);
		revale =1;		
	}
	SPI_RW_Reg(WRITE_REG_NRF24L01 + STATUS,status); 
	CE(1);
	return revale;	
}

 
void nRF24L01_TxPacket(unsigned char * tx_buf)
{
	CE(0);		
	SPI_Write_Buf(WRITE_REG_NRF24L01 + RX_ADDR_P0, TX_ADDRESS, TX_ADR_WIDTH);
	SPI_Write_Buf(WR_TX_PLOAD, tx_buf, TX_PLOAD_WIDTH); 		
	SPI_RW_Reg(WRITE_REG_NRF24L01 + CONFIGA, 0x0e);   		 
	CE(1);		 
	delay1us(10);
}

void RX_Mode(void)
{
	CE(0);
  	SPI_Write_Buf(WRITE_REG_NRF24L01 + RX_ADDR_P0, TX_ADDRESS, TX_ADR_WIDTH); 
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + RX_PW_P0, TX_PLOAD_WIDTH);  
 
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_AA, 0x3f);               
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_RXADDR, 0x3f);           
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_CH, 40);                

  	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_SETUP, 0x07);            
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + CONFIGA, 0x0f);            
  	CE(1);
}

void TX_Mode(u8 * tx_buf)
{
	CE(0);
  	SPI_Write_Buf(WRITE_REG_NRF24L01 + TX_ADDR, TX_ADDRESS, TX_ADR_WIDTH);     
  	SPI_Write_Buf(WRITE_REG_NRF24L01 + RX_ADDR_P0, TX_ADDRESS, TX_ADR_WIDTH);
  	SPI_Write_Buf(WR_TX_PLOAD, tx_buf, TX_PLOAD_WIDTH); 			
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_AA, 0x3f);      
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_RXADDR, 0x3f);  
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + SETUP_RETR, 0x0a);  
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_CH, 40);        
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_SETUP, 0x07);    
	SPI_RW_Reg(WRITE_REG_NRF24L01 + RX_PW_P0, TX_PLOAD_WIDTH);
  	SPI_RW_Reg(WRITE_REG_NRF24L01 + CONFIGA, 0x0e);      
	CE(1);
	delay1us(10);
} 

void nRF24L01_Initial(void)
{


}


void nRF24L01_Config(void)
{
          //initial io
	//CE(0);          //        CE=0 ;chip enable
	//CSN(1);       //CSN=1   Spi disable
	SPI_RW_Reg(WRITE_REG_NRF24L01 + CONFIGA, 0x0e); // Set PWR_UP bit, enable CRC(2 bytes) &Prim:RX. RX_DR enabled..
	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_AA, 0x3f);
	SPI_RW_Reg(WRITE_REG_NRF24L01 + EN_RXADDR, 0x3f); // Enable Pipe0
//	SPI_RW_Reg(WRITE_REG_NRF24L01 + SETUP_AW, 0x02); // Setup address width=5 bytes
//	SPI_RW_Reg(WRITE_REG_NRF24L01 + SETUP_RETR, 0x1a); // 500us + 86us, 10 retrans...
	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_CH, 40);
	SPI_RW_Reg(WRITE_REG_NRF24L01 + RF_SETUP,0x07); // TX_PWR:0dBm, Datarate:2Mbps,
}
 
void NRF24L01_Send(void)
{
    u8 status=0x00;
//	CSN(0);
	TX_Mode(TX_BUF);
	while(IRQ);

	CE(0);
	delay1us(10);
	status=SPI_Read_Reg(STATUS);
	if(status&TX_DS)	/*tx_ds == 0x20*/
	{


PORTB=0X0F;
		SPI_RW_Reg(WRITE_REG_NRF24L01 + STATUS, 0x20);   
			
	}
	else if(status&MAX_RT)
		{
	
PORTB=0XFF;		
	SPI_RW_Reg(WRITE_REG_NRF24L01 + STATUS, 0x10);     			
		}
	CE(1);
//	status=20;
}

void NRF24L01_Receive(void)
{   
    u8 i,status=0x01;  

	RX_Mode();
	while(IRQ);

	CE(0);
	delay1us(10);
	status=SPI_Read_Reg(STATUS);

	if(status & 0x40)		
	{PORTB=0X33;

//		CE(1);
		SPI_Read_Buf(RD_RX_PLOAD,RX_BUF,TX_PLOAD_WIDTH);// read receive payload from RX_FIFO buffer
		
		for(i=0;i<32;i++)
		{
	
       PORTB=RX_BUF[i];TXREG=RX_BUF[i];delay1us(30000);
		
		}
		SPI_RW_Reg(WRITE_REG_NRF24L01 + STATUS, 0x40);    
	}  
	CE(1);

}









