 /*
*========================================================================================================
*
* File                : Interrupts_LED.c
* Hardware Environment:	OpenPIC16F877A && LED && 1KEY && 5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>              
 __CONFIG(0xFF32);           
void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}

void INT_0(void) 
 { 
  TRISB=0x01;
  INTEDG=0;  
  INTF=0;    
  INTE=1;   
  GIE=1;   
 } 

void interrupt INT(void) 
{ 
  if(INTF)              
    { 
       
      INTF=0; 
      RB1=!RB1; delay(100);
     } 
}  
  

void main(void) 
{ 
 
   
  TRISB=0x01;
  PORTD=0x00;
  INT_0(); 
  while(1) 
  { 
    
  } 
}

