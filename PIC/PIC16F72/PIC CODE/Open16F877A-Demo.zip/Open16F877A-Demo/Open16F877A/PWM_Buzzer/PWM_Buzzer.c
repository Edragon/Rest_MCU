/********************************************************************************************************
*********************************************************************************************************
*
* File                : PWM_Buzzer.c
* Hardware Environment:	OpenPIC16F877A && BUZZER  && 5v voltage && 4M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
//RC2/RB0
#include<pic.h>              
//#include<pic168xa.h>         
 __CONFIG(0xFF32);           

void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}


void CCP1INIT() 
{ 
 CCPR1L=0X7F; 
 CCP1CON=0X3C;
     
 INTCON=0X00; 
 PR2=0XFF;  
 TRISC=0XFB;  
 }
main() 
{ 
 
 unsigned int  i;  
 TRISB=0;
 while(1)
{      
    for(i=0;i<60;i++){RB1=1;}
    for(i=0;i<60;i++){RB1=0;}
} 

} 
 
