
#include "clk.h"
 __CONFIG(0xFF32);
void LCD_test(void);
void DisplayString(u8 *s,u8 x,u8 y,u8 Reverse);


void init_mcu(void)
{
	TRISA=0x01;     //////////////////
  	TRISD=0x0;
	TRISC0=0;
TRISC1=0;
TRISC2=0;
}


void main(void)
{
	////init_clk();
	init_mcu();
	init_lcd();
    
    LCD_test();
	TRISB=0;PORTB=0XF0;delay_ms(100);
	DisplayString("WaveShare",6,9,0);
	DisplayString("WaveShare",6,10,1);
	TRISB=0;PORTB=0X0f;delay_ms(100);
	while(1){
		
		delay_ms(5);

		/**/
		if(!PENIRQ){
			if(get_point_xy()){
				draw_lcd();
							  }
		}
	}
}
