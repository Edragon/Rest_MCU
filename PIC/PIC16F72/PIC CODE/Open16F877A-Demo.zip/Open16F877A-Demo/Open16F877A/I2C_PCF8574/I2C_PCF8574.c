/********************************************************************************************************
*********************************************************************************************************
*
* File                : I2C_PCF8574.c
* Hardware Environment:	OpenPIC16F877A && PCF8574 && 8LED && 5v voltage && 4M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include  <pic.h>
 __CONFIG(0xff32); 
typedef unsigned short u16;
typedef unsigned char  u8;
volatile       bit	STAT_RW		@ (unsigned)&SSPSTAT*8+2;
volatile       bit	STAT_BF		@ (unsigned)&SSPSTAT*8+0;


//#define read_ADD  0x41
#define write_ADD 0x40 
#define nop() asm("asm")  

void delay_ms( unsigned int x)
{
    unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
void delay_1ms()
 {
    int i;
    for(i=0;i<100;i++)
       {;}
 }
void twi_init()
  {
   STATUS=0X0; 
   TRISC=0XF0;  
   SSPADD=0X9;
   SSPSTAT=0X80;
   SSPCON=0X38;
  }
void i2c_idle()
 {
   while(STAT_RW);
   ZERO=0;
   while(ZERO)
     {
       SSPCON2&0x1f;
     }
 }
void wrtacktest()
 {
   while(!SSPIF);
   SSPIF=0;
 }


void Write_PCF8574(u8 data)
{
    i2c_idle();
    SEN=1;
    while(!SSPIF);
    SSPIF=0;

    SSPBUF=((u8)((u16)write_ADD)>>8);
    wrtacktest();
    while(STAT_BF);

    SSPBUF=(u8)((u16)write_ADD);
    wrtacktest();
    while(STAT_BF);
 

         SSPBUF=data;
         wrtacktest();
     
    PEN=1;   
     nop();	
    SSPIF=0;
 
}

 main(void)
{
	u8 tmp=0;
	twi_init();
	while(1)
	{
		Write_PCF8574(tmp);
		tmp++;
		delay_ms(50);
	}
}
 