 /*
*========================================================================================================
*
* File                : 8 Push Buttons.c
* Hardware Environment:	OpenPIC16F877A && 8 Push Buttons && 8Userkey && 5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
*
*
*========================================================================================================
*/
#include<pic.h>              
#define  led_out  PORTB
#define  PORT_Crol  TRISB
#define  PIN_Check0  RD0
#define  PIN_Check1  RD1
#define  PIN_Check2  RD2
#define  PIN_Check3  RD3
#define  PIN_Check4  RD4
#define  PIN_Check5  RD5
#define  PIN_Check6  RD6
#define  PIN_Check7  RD7
 __CONFIG(0xFF32);

void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
unsigned char Userkey_scan()
{
    unsigned char result;
    if(PIN_Check0==0)result=1;
    if(PIN_Check1==0)result=2;   
    if(PIN_Check2==0)result=3;
    if(PIN_Check3==0)result=4;
    if(PIN_Check4==0)result=5;
    if(PIN_Check5==0)result=6;   
    if(PIN_Check6==0)result=7;
    if(PIN_Check7==0)result=8;   
    return  result;
}
void Deal ()
{
 	 if(Userkey_scan()==0)led_out=0X00;
 	 if(Userkey_scan()==1)led_out=0X01;
 	 if(Userkey_scan()==2)led_out=2;
 	 if(Userkey_scan()==3)led_out=3;
 	 if(Userkey_scan()==4)led_out=4;
 	 if(Userkey_scan()==5)led_out=5;
 	 if(Userkey_scan()==6)led_out=6;
 	 if(Userkey_scan()==7)led_out=7;
 	 if(Userkey_scan()==8)led_out=8;
}
void PORT_INT()
{
     PORT_Crol=0;
     led_out=0X00;

     TRISD=0x0;
     PORTD=0XFF;
}
 void main()                
  { unsigned char  i,a;
    
    PORT_INT();
    delay(500);
    while(1)               
      {   
      Deal();   
      }
  }


