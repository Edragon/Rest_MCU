 /*
*========================================================================================================
*
* File                : JOYSTICK.c
* Hardware Environment:	OpenPIC16F877A && 8LED && JOYSTICK && 5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>                
 __CONFIG(0xFF32);
void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
unsigned char Userkey_scan()
{
    unsigned char result;
     if(RD7==0){ result=1;}
     if(RD6==0){ result=2;}
     if(RD5==0){ result=3;}
     if(RD4==0){ result=4;}
 	 if(RD3==0){ result=5;}
     if(PORTD==0Xff){ result=0;}
     return  result;
   
}
void Deal ()
{switch (Userkey_scan())
    { 
 	 case 0 :  PORTB=0X00;break;
 	 case 1 :  PORTB=1;break;
 	 case 2 :  PORTB=2;break;
     case 3 :  PORTB=3;break;
 	 case 4 :  PORTB=4;break;
     case 5 :  PORTB=5;break;
     default:   PORTB=0X7;break;  
   }
}
void PORT_INT()
{
     TRISB=0;
     PORTB=0X00;

     TRISD=0;
	 PORTD=0XFF;
 	
}
 void main()              
  { unsigned char  i,a;
    
    PORT_INT();
    delay(1000);
    while(1)                
      {   
      Deal();   
      }
  }


