/*
*========================================================================================================
*
* File                :PS2.h
* Hardware Environment:	OpenPIC18F4520 && 1602 && 5v voltage && 4M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76
* By                  : Zhou Jie
*
*                                  (c) Copyright 2011-2016, WaveShare
*                                       http://www.waveShare.net
*                                          All Rights Reserved
*
*========================================================================================================
*/

#define SET_PS2_DA()	RB1=1
//#define CLR_PS2_DA()	RB1=0
#define IN_PS2_DA()		TRISB1=1
//#define OUT_PS2_DA()	TRISB1=0
#define GET_PS2_DA()  	RB1

#define SET_PS2_CL()	RB0=1
//#define CLR_PS2_CL()	RB0=0
#define IN_PS2_CL()		TRISB0=1
//#define OUT_PS2_CL()	TRISB0=0

#define uint8_t  unsigned char

#define PS2_BUFFER_SIZE 8	
volatile  uint8_t ps2_buffer[PS2_BUFFER_SIZE];	

volatile  uint8_t ps2_status;	
volatile  uint8_t ps2_data;		
volatile  uint8_t ps2_parity;	

volatile  uint8_t ps2_wr_index,ps2_rd_index,ps2_counter;

uint8_t ps2GetCode(void)
{
uint8_t data;
while(!ps2_counter);
data=ps2_buffer[ps2_rd_index];	
if (++ps2_rd_index == PS2_BUFFER_SIZE) ps2_rd_index=0;	
//cli();
--ps2_counter;
//sei();
return data;
}

void ps2Init(void)
{
ps2_status=0;
ps2_data=0;
ps2_parity=0;

ps2_wr_index=0;
ps2_rd_index=0;
ps2_counter=0; 

IN_PS2_CL();
SET_PS2_CL();
IN_PS2_DA();
SET_PS2_DA();
}

