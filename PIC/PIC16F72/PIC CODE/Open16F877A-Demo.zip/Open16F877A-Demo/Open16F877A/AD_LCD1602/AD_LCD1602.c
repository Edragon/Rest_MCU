/*
*========================================================================================================
*
* File                : AD_LCD1602.c
* Hardware Environment:	OpenPIC16F877A  && 1602 && 5v voltage && 4M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76
*
*
*========================================================================================================
*/
#include<pic.h>
 __CONFIG(0xFF32);        
#define rs RC4
#define rw RC5
#define e  RC6

void  AD_PORT_init();
void write(char x);            
void lcd_enable();           
void delay();                  
void LCD1602_PORT_init();
void lcd_init();
void show();

void delay1(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}

void main()
 {  
LCD1602_PORT_init(); 
   AD_PORT_init();
   lcd_init(); 
   
   PORTD=0X1;                
   lcd_enable();
    while(1)
      {             
        show();           
        delay1(1000); 
      }
 } 

 void  AD_PORT_init()               
  {
   PORTA=0XFF;               
   TRISA=0X1;                  
   ADCON1=0X8E;              
   ADCON0=0X41;              
   delay();                  
   } 

void LCD1602_PORT_init()
 {
   
    TRISC=0X00;               
    TRISD=0X00;               
 }

void lcd_init()
 {
    PORTD=0X1;               
    lcd_enable();
    PORTD=0X38;                
    lcd_enable();
    PORTD=0X0e;               
    lcd_enable();
    PORTD=0X06;               
    lcd_enable();
    PORTD=0X80;                
    lcd_enable();
 }
 

void show()
 {  unsigned char result;
     GO=0X1;              
     while(GO);         
     result=ADRESL;  
     PORTD=0X80; 
     lcd_enable();
     write(result/100+0x30);
     write(result%100/10+0x30);
     write(result%100%10+0x30);
     
     PORTD=0Xc0; 
     lcd_enable();
     write((result*20/1000)+0x30);
     write((result*20%1000/100)+0x30);
     write((result*20%1000%100/10)+0x30);
     write((result*20%1000%100%10)+0x30);
     write(' ');
     write('m');
     write('v');

 }

void write(char x)
 {
  PORTD=x;                  
  rs=1;                     
  rw=0;                     
  e=0;                     
  delay();               
  e=1;                      
 }


void lcd_enable()
 {
   rs=0;                     
   rw=0;                     
   e=0;                      
   delay();                  
   e=1;                     
 }

void delay()
 {
   int i;
   for(i=0;i<19;i++);
 }
