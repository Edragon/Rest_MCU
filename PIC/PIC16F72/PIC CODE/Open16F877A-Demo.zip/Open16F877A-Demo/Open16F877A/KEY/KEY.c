 /*
*========================================================================================================
*
* File                : KEY.c
* Hardware Environment:	OpenPIC16F877A && 8LED && 5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>              
#define  led_out  PORTB
#define  PORT_Crol  TRISB
#define  PIN_Check0  RD0
#define  PIN_Check1  RD1
 __CONFIG(0xFF32);

void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
unsigned char Userkey_scan()
{
    unsigned char result;
    if(PIN_Check0==0)result=1;
    if(PIN_Check1==0)result=2;     
    return  result;
}
void Deal ()
{
 	 if(Userkey_scan()==0)led_out=0X00;
 	 if(Userkey_scan()==1)led_out=0X0f;
 	 if(Userkey_scan()==2)led_out=0Xf0;
}
void PORT_INT()
{
     PORT_Crol=0;
     led_out=0X00;

     TRISD=0;
     PORTD=0XFF;
}
 void main()               
  { unsigned char  i,a;
    
    PORT_INT();
    delay(500);
    while(1)               
      {   
      Deal();   
      }
  }


