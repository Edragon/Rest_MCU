/*
*========================================================================================================
*
* File                : I2C_PCF8563.c
* Hardware Environment:	OpenPIC16F877A && PCF8563 && segment && 5v voltage && 4M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>
 __CONFIG(0xff32); 
unsigned char table0[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
       0x88,0x83,0xc6,0xa1,0x86,0x8e,0};  
unsigned char table1[]={0x21,0x22,0x24,0x28 } ;
#define changeHexToInt(hex)		( ( ((hex)>>4) *10 ) + ((hex)%16) )
#define MIN    0x02  
#define SEC    0x03 
#define HOUR   0x04 
#define DAY    0x05 
#define WEEK   0x06 
#define MONTH  0x07 
#define YEAR   0x08 
#define read_ADD  0xA3 
#define write_ADD 0xA2 
volatile       bit	STAT_RW		@ (unsigned)&SSPSTAT*8+2;
volatile       bit	STAT_BF		@ (unsigned)&SSPSTAT*8+0;
#define nop() asm("asm")            
unsigned char g8563_Store[4]; 
unsigned char  c8563_Store[4]={0x00,0x59,0x07,0x01};
void show(unsigned char show_bit,unsigned char show_code);

void write();
void read();
void wrtacktest();
void i2c_idle();
void delay();

void i2cint();
void delay1( unsigned int x)
{
    unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
void sigma_portint()
{
    TRISA=0X00;               
    TRISB=0X00;               
}
void show(unsigned char show_bit,unsigned char show_code)
{
    PORTA=table1[show_bit];
    PORTB=table0[show_code];
  	delay1(1);

}
void i2cint()
  {
   STATUS=0X0;
   
  
   TRISC=0X00;
  
  
  
   SSPADD=0X9;
   SSPSTAT=0X80;
   SSPCON=0X38;
  }
  
void write_CFGbyte(unsigned char CFG_add,unsigned char CFG_data)
  {
   
    i2c_idle();
    SEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=write_ADD;
    wrtacktest();
    while(STAT_BF);
    SSPBUF=CFG_add;
    wrtacktest();
    while(STAT_BF);
 

         SSPBUF=CFG_data;
         wrtacktest();
     
    PEN=1;
    nop();
    SSPIF=0;
 
    delay();

 }

unsigned char receive_CFGbyte(unsigned char CFG_add) 
 {
    unsigned char  receive_da; 
    i2c_idle();
    SSPIF=0;
    SEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=write_ADD;
    wrtacktest();
    SSPBUF=CFG_add;
    wrtacktest();
    
    i2c_idle();
    SSPIF=0;
    RSEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=read_ADD;
    wrtacktest();
   
   
          RCEN=1;
          while(!SSPIF);
          receive_da=SSPBUF;
          while(!SSPIF);
          SSPIF=0;
         
              
                ACKDT=1;
            
          ACKEN=1;
          while(!SSPIF);
          SSPIF=0;
       
   
    PEN=1;
    while(!SSPIF);
    SSPIF=0;
	return	receive_da ; 
 }
     
void wrtacktest()
 {
   while(!SSPIF);
   SSPIF=0;
 }

void i2c_idle()
 {
   while(STAT_RW);
   ZERO=0;
   while(ZERO)
     {
       SSPCON2&0x1f;
     }
 }
    

void delay()
 {
    int i;
    for(i=0;i<100;i++)
       {;}
 }



void P8563_settime() 
{ 
     unsigned char i; 
     for(i=2;i<=4;i++) { write_CFGbyte(i,c8563_Store[i-2]); } 
     write_CFGbyte(6,c8563_Store[3]); 
     
} 

void P8563_init() 
{ 
    unsigned char i; 
    if((receive_CFGbyte(0x0a))!=0x8)
    { 
        for(i=0;i<=3;i++)  
        g8563_Store[i]=c8563_Store[i]; 
        P8563_settime(); 
        write_CFGbyte(0x0,0x00); 
        write_CFGbyte(0xa,0x8); 
        write_CFGbyte(0x01,0x12);
        write_CFGbyte(0xd,0xf0); 
    } 
} 

void receive_CFGNbyte(unsigned char CFG_add, unsigned char n,unsigned char * buff) 
 {
   unsigned char  receive_da,i=0; 
    i2c_idle();
    SSPIF=0;
    SEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=write_ADD;
    wrtacktest();
    SSPBUF=CFG_add;
    wrtacktest();
    
    i2c_idle();
    SSPIF=0;
    RSEN=1;
    while(!SSPIF);
    SSPIF=0;
    SSPBUF=read_ADD;
    wrtacktest();
   
   
         	while(n--)
       {
          RCEN=1;
          while(!SSPIF);
          receive_da=SSPBUF;
         
          while(!SSPIF);
          SSPIF=0;
		  buff[i++]=receive_da;
          if(n<=1) 
              {
                ACKDT=1;
              }
          else     
              {
                ACKDT=0;
              }
          ACKEN=1;
          while(!SSPIF);
          SSPIF=0;
       }
       
   
    PEN=1;
//   while(!SSPIF);
    SSPIF=0;

 }
void P8563_Readtime() 
{   unsigned char time[7];    
    receive_CFGNbyte(MIN,0x07,time); 
    g8563_Store[0]=time[0]&0x7f; 
    g8563_Store[1]=time[1]&0x7f; 
    g8563_Store[2]=time[2]&0x3f; 
    g8563_Store[3]=time[4]&0x07; 
      
    g8563_Store[0]=changeHexToInt(g8563_Store[0]);
	g8563_Store[1]=changeHexToInt(g8563_Store[1]);
    g8563_Store[2]=changeHexToInt(g8563_Store[2]);
	g8563_Store[3]=changeHexToInt(g8563_Store[3]);
} 

void main()
 { unsigned char  m,n=0xD6;
    sigma_portint();
     i2cint();
    P8563_init() ;
    P8563_settime();
 
    while(1)
      {
      m=g8563_Store[0];
      P8563_Readtime();
      show(0,g8563_Store[2]/10);
      show(1,g8563_Store[2]%10);
      show(2,g8563_Store[1]/10);
      show(3,g8563_Store[1]%10);
      
      PORTB=0xFF;     
      if(g8563_Store[0]!=m) {n=~n;PORTA=n;}
      else   PORTA=n;
      delay1(1);
    
      }
 }

 
