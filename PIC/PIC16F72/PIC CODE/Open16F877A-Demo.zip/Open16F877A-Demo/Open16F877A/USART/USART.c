/*
*========================================================================================================
*
* File                : USART.c
* Hardware Environment:	OpenPIC16F877A && rs232 &&  5v voltage && 4M crystal oscillator
* Build Environment   : MPLAB IDE && sscom32
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>         
 __CONFIG(0xFF32);        


void main()
 {
  TRISC=0X0;                 
  SPBRG=0XC;                 
  TXSTA=0X24;               
  RCSTA=0X90;               
  RCIE=0X1;                  
  GIE=0X1;                   
  PEIE=0X1;                
  while(1)                 
   {;}
  }


void interrupt usart(void)
  {
   if(RCIE&&RCIF)           
     {
      TXREG=RCREG;          
     }
   }
