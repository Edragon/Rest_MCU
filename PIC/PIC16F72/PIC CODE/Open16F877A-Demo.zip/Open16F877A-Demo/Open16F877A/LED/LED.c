/*
*========================================================================================================
*
* File                : LED.c
* Hardware Environment:	OpenPIC16F72 && 8LED && 5v voltage && 4M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/

#include<pic.h>            
 __CONFIG(0xff32);           
void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
 void main()               
  { unsigned char  i,a;
    TRISB=0;PORTB=0;
    while(1)               
      {   
          /*PORTB=0;
 delay(500);
 PORTB=0xff;
 delay(500);*/
         a=0x01;
         for(i=0;i<8;i++)
         {
         PORTB=a;
		 delay(100);
     	 a<<=1;
         
		 };
      }
  }


