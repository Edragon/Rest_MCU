/*
*========================================================================================================
*
* File                : CCP1_Infrared.c
* Hardware Environment:	OpenPIC16F877A && REMOTE && 8LED && 5v voltage && 4M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
#include<pic.h>            
 __CONFIG(0xFF32);           
unsigned int n=0,result;
  unsigned char  m[9];
void delay(unsigned int  x)
{
  	unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
void ccp_interrupt_init()
{
TRISC2=1;//CCP1����Ϊiuput
TRISD=0;

GIE=1;			//ȫ���ж�����λ 1�����ж� 0��ֹ
PEIE=1;			//�����ж�����λ 1���� 0��ֹ

CCP1IE=1;		//ccp1�ж�����λ 1���� 0��ֹ
CCP1CON=0X04;
CCP1IF=0;

  T1CKPS0=0;         
  T1CKPS1=0;                
  TMR1CS=0;                 
  
  TMR1IE=1;  		//Timer1�ж�����λ 1���� 0��ֹ
  TMR1L=0;//(65536-65500)%256;  
  TMR1H=0;(65536-65500)/256; 
 TMR1ON=1;  

}

void interrupt ccp()
{
unsigned char i;
if(TMR1IE && TMR1IF)
   {
    TMR1IF=0;
    TMR1L=0;
    TMR1H=0;
   }



 if(CCP1IF)
   {  n++;
     CCP1IE=0; 
CCP1IF=0;
 if(n==20) 
    {TMR1L=0;
    TMR1H=0;
    }
     else if((20< n ) &&  (n<=28)){ m[n-21]=CCPR1H;}
    TMR1L=0;
    TMR1H=0;
    
    	
    if(n==36)
     {
     n=0; 
     for(i=0;i<8;i++)  
	{result>>=1;
	if(m[i]>6)result|=0x80;
    
	}
   	 }   CCP1IE=1;
   } 
}




main()
{unsigned char i;
ccp_interrupt_init();
TRISB=0X00;
while(1)
{
if(n>30)
{
	delay(500);
     if(n!=0){n=0;};
}
PORTB=result;

} 
}