/*
*========================================================================================================
*
* File                : LCD1602.c
* Hardware Environment:	OpenPIC16F877A && 1602 && 5v voltage && 4M crystal oscillator
 && 
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/

#include<pic.h>
 __CONFIG(0xff32);        

#define rs RC4
#define rw RC5
#define e  RC6
const char web[ ]={' ',' ',' ','w','a','v','e','s','h','a','r','e',' ',' ',' ',' '};

const char tel[ ]={' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '};


void LCE_PORT_init();                
void lcd_init();              
void write(char x);           
void lcd_enable();            
void LCD_delay();             
void write_web();            
void write_tel();           
                 
void main()
 { LCE_PORT_init(); lcd_init(); 
    while(1)
      {
                     
                   
        write_web();           
        PORTD=0XC0;           
        lcd_enable();          
        write_tel();  
      }
 }

void LCD_delay()
 {
   int i;
   for(i=0;i<19;i++);
 } 

void LCE_PORT_init()
 {
   
    TRISC=0X00;               
    TRISD=0X00;               
 }

void lcd_enable()
 {
   rs=0;                     
   rw=0;                    
   e=0;                     
   LCD_delay();                 
   e=1;                   
 }

void lcd_init()
 {
    PORTD=0X1;                 
    lcd_enable();
    PORTD=0X38;                
    lcd_enable();
    PORTD=0X0e;                
    lcd_enable();
    PORTD=0X06;                
    lcd_enable();
    PORTD=0X80;                
    lcd_enable();
 }

void write(char x)
 {
  PORTD=x;                  
  rs=1;                     
  rw=0;                     
  e=0;                      
  LCD_delay();               
  e=1;                       
 } 

void write_web()
 {
    int i;
    for(i=0;i<0x10;i++)        
       {
         write(web[i]);        
       }
 }

 void write_tel()
 {
    int i;
    for(i=0;i<0x10;i++)       
       {
         write(tel[i]);       
       }
 }
  





