 /*
*========================================================================================================
*
* File                : SPI_AT45DBXX.c
* Hardware Environment:	OpenPIC16F877A && 8LED && AT45DBXX && 5v voltage && 4M/8M crystal oscillator
* Build Environment   : MPLAB IDE
* Version             : V8.76

*
*========================================================================================================
*/
 #include<pic.h>
 __CONFIG(0xFF32);        

 #define   c_s      RA5
 #define   nop()    asm("nop")

 void      init();
void ee_write(unsigned int BufferOffset,unsigned char data);
unsigned char ee_read(unsigned int BufferOffset);

 void      delay();

void 	spi_transmit_byte(unsigned char x);

void _delay_ms( unsigned int x)
{
    unsigned int  i,j;
    for(i=0;i<x;i++)
       for(j=0;j<100;j++);
}
void  main()
  {	unsigned char num,i;
     init();
     while(1)
       {
              
		
		   /* *///if(!RD0){}
               PORTB=0X0F;_delay_ms(500);
                for(num=0;num<255;num++)
					{
						ee_write((unsigned int)num,num);
	    				for(i=0;i<40;i++);
					
					}	PORTB=0XF0;
              
           //if(!RD1){}
              PORTB=0X55;_delay_ms(500);
                	for(num=0;num<255;num++)
					{
					PORTB=ee_read((unsigned int)num);
					_delay_ms(50);
					}
                // while(1)PORTB=0XCC;
              
       }
   }

void init()
   {
   TRISA=0X00;
     TRISB=0X00;PORTB=0X00;
     TRISC=0X00; 
     TRISD=0XFF;
     PORTD=0XFF;
     SSPSTAT=0X80;//////////////c0
     SSPCON=0X30;////////////20
    INTCON=0X00;
     PIR1=0X00;
    // c_s=1;
   }

void ee_write(unsigned int BufferOffset,unsigned char data)
   {
     
     c_s=0;
     
	spi_transmit_byte(0x84);//84			  						
	spi_transmit_byte(0xff);						
	spi_transmit_byte((unsigned char)(BufferOffset>>8));	
	spi_transmit_byte((unsigned char)BufferOffset);		
	spi_transmit_byte(data);		        

    c_s=1;
    
   }

unsigned char ee_read(unsigned int BufferOffset)
   {
      unsigned char temp;   
    c_s=0; 
     nop();
     nop();
 	spi_transmit_byte(0xD4);//54
	spi_transmit_byte(0xff);
	spi_transmit_byte((unsigned char)(BufferOffset>>8));
	spi_transmit_byte((unsigned char)BufferOffset);
	spi_transmit_byte(0xff);
	spi_transmit_byte(0xff);
	temp=SSPBUF;	  

   		
     nop();
     c_s=1;
     nop();
      return temp;	
   }
     

void 	spi_transmit_byte(unsigned char x)
   {
     SSPBUF=x;
     while(!SSPIF);
     SSPIF=0;
     
   }


void  delay()
   {
     int i;
     for(i=100;i>0;i--);
   }
