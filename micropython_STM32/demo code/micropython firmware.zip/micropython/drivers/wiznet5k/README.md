This is the driver for the WIZnet5x00 series of Ethernet controllers.

Adapted for Micro Python.

Original source: https://github.com/Wiznet/W5500_EVB/tree/master/ioLibrary
Taken on: 30 August 2014
