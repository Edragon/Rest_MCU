:mod:`uzlib` -- zlib decompression
==================================

.. module:: uzlib
   :synopsis: zlib decompression

This modules allows to decompress binary data compressed with DEFLATE
algorithm (commonly used in zlib library and gzip archiver). Compression
is not yet implemented.

Functions
---------

.. function:: decompress(data)

   Return decompressed data as bytes.
